﻿using System.Collections.Concurrent;

public class InMemoryDatabase
{
    public ConcurrentDictionary<Guid, Student> Students { get; } = new();
    public ConcurrentDictionary<Guid, Class> Classes { get; } = new();
    public ConcurrentDictionary<Guid, Enrollment> Enrollments { get; } = new();
    public ConcurrentDictionary<Guid, Mark> Marks { get; } = new();
    public Enrollment? FindEnrollment(Guid studentId, Guid classId)
        => Enrollments.Values.FirstOrDefault(e => e.StudentId == studentId && e.ClassId == classId);
}
