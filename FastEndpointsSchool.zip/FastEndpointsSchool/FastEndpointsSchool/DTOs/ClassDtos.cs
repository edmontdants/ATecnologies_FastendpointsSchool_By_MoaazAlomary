﻿public class CreateClassRequest
{
    public string Name { get; set; } = "";
    public string Teacher { get; set; } = "";
    public string? Description { get; set; }
}

public class ClassResponse
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string Teacher { get; set; } = "";
    public string? Description { get; set; }
}
