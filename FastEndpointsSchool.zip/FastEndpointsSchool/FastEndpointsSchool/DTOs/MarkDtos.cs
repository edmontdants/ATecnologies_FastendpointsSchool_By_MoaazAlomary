﻿public class CreateMarkRequest
{
    public Guid StudentId { get; set; }
    public Guid ClassId { get; set; }
    public decimal ExamMark { get; set; }
    public decimal AssignmentMark { get; set; }
}

public class MarkResponse
{
    public Guid Id { get; set; }
    public Guid StudentId { get; set; }
    public Guid ClassId { get; set; }
    public decimal ExamMark { get; set; }
    public decimal AssignmentMark { get; set; }
    public decimal TotalMark { get; set; }
}
