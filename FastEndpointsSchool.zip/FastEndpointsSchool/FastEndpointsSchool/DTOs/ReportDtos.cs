﻿public class StudentClassMark
{
    public Guid ClassId { get; set; }
    public string ClassName { get; set; } = "";
    public decimal ExamMark { get; set; }
    public decimal AssignmentMark { get; set; }
    public decimal Total { get; set; }
}

public class StudentReportResponse
{
    public Guid StudentId { get; set; }
    public string StudentName { get; set; } = "";
    public List<StudentClassMark> ClassMarks { get; set; } = new();
    public decimal OverallAverage { get; set; }
}
