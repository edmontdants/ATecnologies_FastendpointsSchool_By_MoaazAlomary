﻿using FastEndpoints;

public class CreateClassEndpoint : Endpoint<CreateClassRequest, ClassResponse>
{
    private readonly ClassService _svc;
    public CreateClassEndpoint(ClassService svc) => _svc = svc;

    public override void Configure()
    {
        Post("/api/classes");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateClassRequest req, CancellationToken ct)
    {
        var c = _svc.Create(req);
        await Send.OkAsync(new ClassResponse
        {
            Id = c.Id,
            Name = c.Name,
            Teacher = c.Teacher,
            Description = c.Description
        }, ct);
    }
}
