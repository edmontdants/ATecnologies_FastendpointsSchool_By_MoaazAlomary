﻿using FastEndpoints;

public class DeleteClassEndpoint : EndpointWithoutRequest
{
    private readonly ClassService _svc;
    public DeleteClassEndpoint(ClassService svc) => _svc = svc;

    public override void Configure()
    {
        Delete("/api/classes/{id:guid}");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var id = Route<Guid>("id");
        _svc.Delete(id);
        await Send.NoContentAsync(ct);
    }
}
