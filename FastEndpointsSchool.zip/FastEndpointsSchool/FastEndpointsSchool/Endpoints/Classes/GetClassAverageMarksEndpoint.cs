﻿using FastEndpoints;

public class GetClassAverageMarksEndpoint : EndpointWithoutRequest<ClassAverageResponse>
{
    private readonly ClassService _classSvc;
    private readonly MarksService _marksSvc;
    public GetClassAverageMarksEndpoint(ClassService classSvc, MarksService marksSvc)
    {
        _classSvc = classSvc;
        _marksSvc = marksSvc;
    }

    public override void Configure()
    {
        Get("/api/classes/{classId:guid}/average-marks");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var classId = Route<Guid>("classId");
        var cls = _classSvc.GetById(classId);
        if (cls == null)
            throw new ApiException("Class not found", 404);

        var avg = _marksSvc.GetAverageForClass(classId);
        await Send.OkAsync(new ClassAverageResponse
        {
            ClassId = classId,
            ClassName = cls.Name,
            AverageTotal = Math.Round(avg, 2)
        }, ct);
    }
}

public class ClassAverageResponse
{
    public Guid ClassId { get; set; }
    public string ClassName { get; set; } = "";
    public decimal AverageTotal { get; set; }
}
