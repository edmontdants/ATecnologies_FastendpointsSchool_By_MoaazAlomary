﻿using FastEndpoints;

public class GetAllClassesEndpoint : EndpointWithoutRequest<PagedClassesResponse>
{
    private readonly ClassService _svc;
    public GetAllClassesEndpoint(ClassService svc) => _svc = svc;

    public override void Configure()
    {
        Get("/api/classes");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var page = int.TryParse(Query<string?>("page"), out var p) && p > 0 ? p : 1;
        var pageSize = int.TryParse(Query<string?>("pageSize"), out var ps) && ps > 0 ? ps : 10;
        var name = Query<string?>("name");
        var teacher = Query<string?>("teacher");

        var (items, total) = _svc.GetAll(page, pageSize, name, teacher);
        var resp = new PagedClassesResponse
        {
            Page = page,
            PageSize = pageSize,
            Total = total,
            Classes = items.Select(c => new ClassResponse
            {
                Id = c.Id,
                Name = c.Name,
                Teacher = c.Teacher,
                Description = c.Description
            }).ToList()
        };

        await Send.OkAsync(resp, ct);
    }
}

public class PagedClassesResponse
{
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int Total { get; set; }
    public List<ClassResponse> Classes { get; set; } = new();
}
