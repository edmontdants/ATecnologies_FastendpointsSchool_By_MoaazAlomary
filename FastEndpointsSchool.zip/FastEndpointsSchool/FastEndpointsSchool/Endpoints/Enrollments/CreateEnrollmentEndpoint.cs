﻿using FastEndpoints;

public class CreateEnrollmentEndpoint : Endpoint<CreateEnrollmentRequest, EnrollmentResponse>
{
    private readonly EnrollmentService _svc;
    public CreateEnrollmentEndpoint(EnrollmentService svc) => _svc = svc;

    public override void Configure()
    {
        Post("/api/enrollments");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateEnrollmentRequest req, CancellationToken ct)
    {
        var en = _svc.Enroll(req.StudentId, req.ClassId);
        await Send.OkAsync(new EnrollmentResponse
        {
            Id = en.Id,
            StudentId = en.StudentId,
            ClassId = en.ClassId,
            EnrolledAt = en.EnrolledDate
        }, ct);
    }
}
