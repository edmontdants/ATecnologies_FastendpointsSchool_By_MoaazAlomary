﻿using FastEndpoints;

public class CreateMarkEndpoint : Endpoint<CreateMarkRequest, MarkResponse>
{
    private readonly MarksService _svc;
    public CreateMarkEndpoint(MarksService svc) => _svc = svc;

    public override void Configure()
    {
        Post("/api/marks");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateMarkRequest req, CancellationToken ct)
    {
        var mark = _svc.RecordMark(req);
        await Send.OkAsync(new MarkResponse
        {
            Id = mark.Id,
            StudentId = mark.StudentId,
            ClassId = mark.ClassId,
            ExamMark = mark.ExamMark,
            AssignmentMark = mark.AssignmentMark,
            TotalMark = mark.TotalMark
        }, ct);
    }
}
