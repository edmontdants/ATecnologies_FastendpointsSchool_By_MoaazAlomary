﻿using FastEndpoints;

public class GetStudentReportEndpoint : EndpointWithoutRequest<StudentReportResponse>
{
    private readonly MarksService _marksSvc;
    public GetStudentReportEndpoint(MarksService marksSvc) => _marksSvc = marksSvc;

    public override void Configure()
    {
        Get("/api/students/{studentId:guid}/report");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var studentId = Route<Guid>("studentId");
        var report = _marksSvc.GenerateStudentReport(studentId);
        await Send.OkAsync(report, ct);
    }
}
