﻿using FastEndpoints;

public class CreateStudentEndpoint : Endpoint<CreateStudentRequest, StudentResponse>
{
    private readonly StudentService _svc;
    public CreateStudentEndpoint(StudentService svc) => _svc = svc;

    public override void Configure()
    {
        Post("/api/students");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CreateStudentRequest req, CancellationToken ct)
    {
        var s = _svc.Create(req);
        await Send.OkAsync(new StudentResponse
        {
            Id = s.Id,
            FirstName = s.FirstName,
            LastName = s.LastName,
            Age = s.Age
        }, cancellation: ct);
    }
}
