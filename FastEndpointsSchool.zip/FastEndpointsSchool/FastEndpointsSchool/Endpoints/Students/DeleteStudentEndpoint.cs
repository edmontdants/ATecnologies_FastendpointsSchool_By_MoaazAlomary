﻿using FastEndpoints;

public class DeleteStudentEndpoint : EndpointWithoutRequest
{
    private readonly StudentService _svc;
    public DeleteStudentEndpoint(StudentService svc) => _svc = svc;

    public override void Configure()
    {
        Delete("/api/students/{id:guid}");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var id = Route<Guid>("id");
        _svc.Delete(id);
        await Send.NoContentAsync(ct);
    }
}
