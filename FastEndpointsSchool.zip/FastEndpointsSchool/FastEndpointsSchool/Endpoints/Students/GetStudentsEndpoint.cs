﻿using FastEndpoints;

public class GetAllStudentsEndpoint : EndpointWithoutRequest<PagedStudentsResponse>
{
    private readonly StudentService _svc;
    public GetAllStudentsEndpoint(StudentService svc) => _svc = svc;

    public override void Configure()
    {
        Get("/api/students");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken ct)
    {
        var page = int.TryParse(Query<string?>("page"), out var p) && p > 0 ? p : 1;
        var pageSize = int.TryParse(Query<string?>("pageSize"), out var ps) && ps > 0 ? ps : 10;
        var name = Query<string?>("name");
        var age = int.TryParse(Query<string?>("age"), out var a) ? a : (int?)null;

        var (items, total) = _svc.GetAll(page, pageSize, name, age);
        var resp = new PagedStudentsResponse
        {
            Page = page,
            PageSize = pageSize,
            Total = total,
            Students = items.Select(s => new StudentResponse
            {
                Id = s.Id,
                FirstName = s.FirstName,
                LastName = s.LastName,
                Age = s.Age
            }).ToList()
        };
        await Send.OkAsync(resp, ct);
    }
}

public class PagedStudentsResponse
{
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int Total { get; set; }
    public List<StudentResponse> Students { get; set; } = new();
}
