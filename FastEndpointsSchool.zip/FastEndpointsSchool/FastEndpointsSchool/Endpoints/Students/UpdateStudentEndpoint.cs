﻿using FastEndpoints;

public class UpdateStudentEndpoint : Endpoint<UpdateStudentRequest, StudentResponse>
{
    private readonly StudentService _svc;
    public UpdateStudentEndpoint(StudentService svc) => _svc = svc;

    public override void Configure()
    {
        Put("/api/students/{id:guid}");
        AllowAnonymous();
    }

    public override async Task HandleAsync(UpdateStudentRequest req, CancellationToken ct)
    {
        var id = Route<Guid>("id");
        var updated = _svc.Update(id, req);
        await Send.OkAsync(new StudentResponse
        {
            Id = updated.Id,
            FirstName = updated.FirstName,
            LastName = updated.LastName,
            Age = updated.Age
        }, ct);
    }
}
