﻿public class ApiException : Exception
{
    public int Status { get; }
    public ApiException(string message, int status = 400) : base(message)
    {
        Status = status;
    }
}
