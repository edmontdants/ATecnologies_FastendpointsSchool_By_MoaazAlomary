﻿
public class Enrollment
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StudentId { get; set; }
    public Guid ClassId { get; set; }
    public DateTime EnrolledDate { get; set; } = DateTime.UtcNow;
}