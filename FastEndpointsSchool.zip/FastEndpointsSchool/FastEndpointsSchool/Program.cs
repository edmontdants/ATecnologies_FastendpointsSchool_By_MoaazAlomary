using FastEndpoints;
using FastEndpoints.Swagger;
using Newtonsoft.Json;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddSingleton<InMemoryDatabase>();
builder.Services.AddSingleton<StudentService>();
builder.Services.AddSingleton<ClassService>();
builder.Services.AddSingleton<EnrollmentService>();
builder.Services.AddSingleton<MarksService>();

builder.Services.AddFastEndpoints(options =>
{
    options.Assemblies = new[] { typeof(CreateClassEndpoint).Assembly };
}).AddSwaggerDocument();

var app = builder.Build();

app.Use(async (ctx, next) =>
{
    try
    {
        await next();
    }
    catch (ApiException ex)
    {
        ctx.Response.StatusCode = ex.Status;
        ctx.Response.ContentType = "application/json";
        var payload = JsonConvert.SerializeObject(new { error = ex.Message });
        await ctx.Response.WriteAsync(payload);
    }
    catch (Exception ex)
    {
        ctx.Response.StatusCode = 500;
        ctx.Response.ContentType = "application/json";
        var payload = JsonConvert.SerializeObject(new { error = "An unexpected error occurred.", details = ex.Message });
        await ctx.Response.WriteAsync(payload);
    }
});

app.UseRouting();
app.UseFastEndpoints();
app.UseOpenApi();
app.UseSwaggerGen();

app.Run();
