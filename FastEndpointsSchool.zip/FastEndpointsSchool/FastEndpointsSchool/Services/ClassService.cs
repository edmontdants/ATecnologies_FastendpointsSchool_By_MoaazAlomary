﻿
public class ClassService
{
    private readonly InMemoryDatabase _db;
    public ClassService(InMemoryDatabase db) => _db = db;

    public Class Create(CreateClassRequest req)
    {
        var c = new Class
        {
            Name = req.Name.Trim(),
            Teacher = req.Teacher.Trim(),
            Description = req.Description?.Trim()
        };
        _db.Classes[c.Id] = c;
        return c;
    }

    public (IEnumerable<Class> Items, int Total) GetAll(int page, int pageSize, string? nameFilter, string? teacherFilter)
    {
        var q = _db.Classes.Values.AsQueryable();
        if (!string.IsNullOrWhiteSpace(nameFilter))
        {
            var nf = nameFilter.Trim().ToLower();
            q = q.Where(c => c.Name.ToLower().Contains(nf));
        }
        if (!string.IsNullOrWhiteSpace(teacherFilter))
        {
            var tf = teacherFilter.Trim().ToLower();
            q = q.Where(c => c.Teacher.ToLower().Contains(tf));
        }

        var total = q.Count();
        var items = q.Skip((page - 1) * pageSize).Take(pageSize).ToList();
        return (items, total);
    }

    public Class? GetById(Guid id)
        => _db.Classes.TryGetValue(id, out var c) ? c : null;

    public void Delete(Guid id)
    {
        if (!_db.Classes.TryRemove(id, out _))
            throw new ApiException("Class not found", 404);

        var marksToRemove = _db.Marks.Values.Where(m => m.ClassId == id).Select(m => m.Id).ToList();
        foreach (var mid in marksToRemove)
            _db.Marks.TryRemove(mid, out _);
    }
}
