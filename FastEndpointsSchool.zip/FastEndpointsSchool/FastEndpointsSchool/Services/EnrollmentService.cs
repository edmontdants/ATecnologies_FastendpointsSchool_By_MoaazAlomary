﻿public class EnrollmentService
{
    private readonly InMemoryDatabase _db;
    public EnrollmentService(InMemoryDatabase db) => _db = db;

    public Enrollment Enroll(Guid studentId, Guid classId)
    {
        if (!_db.Students.ContainsKey(studentId))
            throw new ApiException("Student not found", 404);
        if (!_db.Classes.ContainsKey(classId))
            throw new ApiException("Class not found", 404);

        var existing = _db.FindEnrollment(studentId, classId);
        if (existing != null)
            throw new ApiException("Student already enrolled in this class", 400);

        var en = new Enrollment
        {
            StudentId = studentId,
            ClassId = classId,
            EnrolledDate = DateTime.UtcNow
        };

        _db.Enrollments[en.Id] = en;
        return en;
    }

    public Enrollment? GetById(Guid id)
        => _db.Enrollments.TryGetValue(id, out var e) ? e : null;

    public IEnumerable<Enrollment> GetByStudent(Guid studentId)
        => _db.Enrollments.Values.Where(e => e.StudentId == studentId);

    public IEnumerable<Enrollment> GetByClass(Guid classId)
        => _db.Enrollments.Values.Where(e => e.ClassId == classId);

    public void Delete(Guid enrollmentId)
    {
        if (!_db.Enrollments.TryRemove(enrollmentId, out var enrollment))
            throw new ApiException("Enrollment not found", 404);

        // also remove related marks for that student/class combination
        var marksToRemove = _db.Marks.Values
            .Where(m => m.StudentId == enrollment.StudentId && m.ClassId == enrollment.ClassId)
            .Select(m => m.Id)
            .ToList();

        foreach (var mid in marksToRemove)
            _db.Marks.TryRemove(mid, out _);
    }
}
