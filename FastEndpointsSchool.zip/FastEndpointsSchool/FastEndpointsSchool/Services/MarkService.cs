﻿public class MarksService
{
    private readonly InMemoryDatabase _db;
    public MarksService(InMemoryDatabase db) => _db = db;

    public Mark RecordMark(CreateMarkRequest req)
    {
        // Ensure student and class exist
        if (!_db.Students.ContainsKey(req.StudentId))
            throw new ApiException("Student not found", 404);
        if (!_db.Classes.ContainsKey(req.ClassId))
            throw new ApiException("Class not found", 404);

        // Validate enrollment
        var enrollment = _db.FindEnrollment(req.StudentId, req.ClassId);
        if (enrollment == null)
            throw new ApiException("Student is not enrolled in the specified class.", 400);

        var mark = new Mark
        {
            StudentId = req.StudentId,
            ClassId = req.ClassId,
            ExamMark = req.ExamMark,
            AssignmentMark = req.AssignmentMark
        };

        _db.Marks[mark.Id] = mark;
        return mark;
    }

    public IEnumerable<Mark> GetMarksForClass(Guid classId)
        => _db.Marks.Values.Where(m => m.ClassId == classId);

    public IEnumerable<Mark> GetMarksForStudent(Guid studentId)
        => _db.Marks.Values.Where(m => m.StudentId == studentId);

    public decimal GetAverageForClass(Guid classId)
    {
        var classMarks = GetMarksForClass(classId).ToList();
        if (!classMarks.Any())
            throw new ApiException("No marks recorded for this class.", 400);

        return classMarks.Average(m => m.TotalMark);
    }

    public StudentReportResponse GenerateStudentReport(Guid studentId)
    {
        if (!_db.Students.TryGetValue(studentId, out var student))
            throw new ApiException("Student not found", 404);

        var marks = GetMarksForStudent(studentId).ToList();
        var report = new StudentReportResponse
        {
            StudentId = studentId,
            StudentName = $"{student.FirstName} {student.LastName}"
        };

        var totals = new List<decimal>();

        // Build class-by-class results
        foreach (var group in marks.GroupBy(m => m.ClassId))
        {
            var classId = group.Key;
            var className = _db.Classes.TryGetValue(classId, out var c) ? c.Name : "Unknown Class";
            var latest = group.Last(); // could sort by timestamp if added later

            var entry = new StudentClassMark
            {
                ClassId = classId,
                ClassName = className,
                ExamMark = latest.ExamMark,
                AssignmentMark = latest.AssignmentMark,
                Total = latest.TotalMark
            };
            report.ClassMarks.Add(entry);
            totals.Add(entry.Total);
        }

        // Include enrolled classes with no marks
        var enrolledClassIds = _db.Enrollments.Values
            .Where(e => e.StudentId == studentId)
            .Select(e => e.ClassId);
        foreach (var cid in enrolledClassIds.Except(marks.Select(m => m.ClassId)))
        {
            var className = _db.Classes.TryGetValue(cid, out var c) ? c.Name : "Unknown Class";
            report.ClassMarks.Add(new StudentClassMark
            {
                ClassId = cid,
                ClassName = className,
                ExamMark = 0,
                AssignmentMark = 0,
                Total = 0
            });
            totals.Add(0);
        }

        report.OverallAverage = totals.Any() ? Math.Round(totals.Average(), 2) : 0m;
        return report;
    }
}
