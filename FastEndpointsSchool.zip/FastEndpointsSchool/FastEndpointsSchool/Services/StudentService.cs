﻿public class StudentService
{
    private readonly InMemoryDatabase _db;
    public StudentService(InMemoryDatabase db) => _db = db;

    public Student Create(CreateStudentRequest req)
    {
        var s = new Student
        {
            FirstName = req.FirstName.Trim(),
            LastName = req.LastName.Trim(),
            Age = req.Age
        };
        _db.Students[s.Id] = s;
        return s;
    }

    public (IEnumerable<Student> Items, int Total) GetAll(int page, int pageSize, string? nameFilter, int? ageFilter)
    {
        var q = _db.Students.Values.AsQueryable();

        if (!string.IsNullOrWhiteSpace(nameFilter))
        {
            var nf = nameFilter.Trim().ToLower();
            q = q.Where(s => (s.FirstName + " " + s.LastName).ToLower().Contains(nf));
        }
        if (ageFilter.HasValue)
        {
            q = q.Where(s => s.Age == ageFilter.Value);
        }

        var total = q.Count();
        var items = q.Skip((page - 1) * pageSize).Take(pageSize).ToList();
        return (items, total);
    }

    public Student? GetById(Guid id)
        => _db.Students.TryGetValue(id, out var s) ? s : null;

    public Student Update(Guid id, UpdateStudentRequest req)
    {
        if (!_db.Students.TryGetValue(id, out var existing))
            throw new ApiException("Student not found", 404);

        existing.FirstName = req.FirstName.Trim();
        existing.LastName = req.LastName.Trim();
        existing.Age = req.Age;
        _db.Students[id] = existing;
        return existing;
    }

    public void Delete(Guid id)
    {
        if (!_db.Students.TryRemove(id, out _))
            throw new ApiException("Student not found", 404);

        var marksToRemove = _db.Marks.Values.Where(m => m.StudentId == id).Select(m => m.Id).ToList();
        foreach (var mid in marksToRemove)
            _db.Marks.TryRemove(mid, out _);
    }
}
