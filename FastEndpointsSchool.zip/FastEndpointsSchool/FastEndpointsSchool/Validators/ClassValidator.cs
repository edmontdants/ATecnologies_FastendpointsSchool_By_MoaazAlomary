﻿using FluentValidation;

public class CreateClassRequestValidator : AbstractValidator<CreateClassRequest>
{
    public CreateClassRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().WithMessage("Class name is required.");
        RuleFor(x => x.Teacher).NotEmpty().WithMessage("Teacher is required.");
    }
}
