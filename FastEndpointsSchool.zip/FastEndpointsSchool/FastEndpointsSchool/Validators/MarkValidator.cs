﻿using FluentValidation;

public class CreateMarkRequestValidator : AbstractValidator<CreateMarkRequest>
{
    public CreateMarkRequestValidator()
    {
        RuleFor(x => x.StudentId).NotEmpty();
        RuleFor(x => x.ClassId).NotEmpty();
        RuleFor(x => x.ExamMark).GreaterThanOrEqualTo(0m);
        RuleFor(x => x.AssignmentMark).GreaterThanOrEqualTo(0m);
    }
}
